import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'

let handler = m => m
handler.all = async function (m) {
    let name = await conn.getName(m.sender)
    let pp = 'https://telegra.ph/file/24fa902ead26340f3df2c.png'
    try {
        pp = await this.profilePictureUrl(m.sender, 'image')
    } catch (e) {
    } finally {
        global.doc = pickRandom(["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/msword", "application/pdf", "application/vnd.android.package-archive", "application/zip"])

        // Module
        global.fetch = fetch

        const _uptime = process.uptime() * 1000

        // Ini untuk command creator/owner
        global.kontak2 = [
            [owner[0], await this.getName(owner[0] + '@s.whatsapp.net'), 'ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ', 'tryarno@gmail.com', true],
            [owner[1], await this.getName(owner[1] + '@s.whatsapp.net'), 'ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ', 'mskarno1@gmail.com', true], // Kalo mau di tambah tinggal copy 1baris ini di tempel di bawahnya trs di edit dikit!
        ]

        // ucapan ini mah
        global.ucapan = ucapan()

        // pesan sementara
        global.ephemeral = null // 86400 = 24jam, kalo ingin di hilangkan ganti '86400' jadi 'null' atau ''
        let urls = pickRandom(['https://avatars.githubusercontent.com/u/87053694?v=4'])
        let res = await fetch('https://raw.githubusercontent.com/Johannes2803/database/main/marin.json')
        let txt = await res.text()
        let arr = JSON.parse(txt) // Mengubah teks menjadi objek JSON
        global.marin = arr[Math.floor(Math.random() * arr.length)]
        //global.marin = pickRandom(["https://raw.githubusercontent.com/Johannes2803/database/main/marin.json"])
        // externalAdReply atau text with thumbnail. gatau bahasa Inggris? coba translate!
        global.adReply = {
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true, // ini biar ada tulisannya diteruskan berkali-kali, jika ingin di hilangkan ganti true menjadi false
                externalAdReply: { // Bagian ini sesuka kalian berkreasi :'v
                    showAdAttribution: false,
                    title: "【 Amel 】",
                    body: '\t' + me,
                    mediaUrl: ' ',
                    description: '',
                    previewType: "PHOTO",
                    thumbnail: await(await fetch(marin)).buffer(),
                    sourceUrl: "https://chat.whatsapp.com/K5xbjxpQgPu1DCPysnrf7d",
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '',
                    newsletterName: '',
                    serverMessageId: 1945
                }
            }
        }
        global.fakeig = {
            contextInfo: { externalAdReply: { showAdAttribution: true, mediaUrl: "https://Instagram.com/rlxfly.uw", mediaType: "VIDEO", description: "https://Instagram.com/rlxfly.uw", title: 'Simple Bot Esm', body: me, thumbnailUrl: pp, sourceUrl: 'http://s.id/0x404' } }
        }
        // Fake 🤥
        global.ftroli = { key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net' }, message: { orderMessage: { itemCount: 999, status: 1, surface: 1, message: me, orderTitle: me, sellerJid: '0@s.whatsapp.net' } } }
        global.fkontak = { key: { fromMe: false, participant: "0@s.whatsapp.net", ...(m.chat ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': me, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${me},;;;\nFN:${me},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': fs.readFileSync('./image/me.png'), thumbnail: fs.readFileSync('./image/me.png'), sendEphemeral: true } } }
        global.fvn = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net", ...(m.chat ?
                    { remoteJid: "17608914335-1625305606@g.us" } : {})
            },
            message: {
                "audioMessage": {
                    "mimetype": "audio/ogg; codecs=opus",
                    "seconds": "999999999999",
                    "ptt": "true"
                }
            }
        }
        global.ftextt = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net", ...(m.chat ?
                    { remoteJid: "17608914335-1625305606@g.us" } : {})
            },
            message: {
                "extendedTextMessage": {
                    "text": me,
                    "title": me,
                    'jpegThumbnail': fs.readFileSync('./image/me.png')
                }
            }
        }
        global.fliveLoc = {
            key: { fromMe: false, participant: "0@s.whatsapp.net", ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
            message: { "liveLocationMessage": { "caption": "Hi", "h": me, 'jpegThumbnail': fs.readFileSync('./image/me.png') } }
        }
        global.fliveLoc2 = {
            key: { fromMe: false, participant: "0@s.whatsapp.net", ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
            message: { "liveLocationMessage": { "title": "Hi There Im Using GitHub", "h": me, 'jpegThumbnail': fs.readFileSync('./image/me.png') } }
        }
        global.ftoko = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net", ...(m.chat ? { remoteJid: "17608914335@s.whatsapp.net" } : {})
            },
            message: {
                "productMessage": {
                    "product": {
                        "productImage": {
                            "mimetype": "image/jpeg",
                            "jpegThumbnail": fs.readFileSync('./image/me.png') //Gambarnye
                        },
                        "title": me, //Kasih namalu 
                        "description": "Simple Bot Esm",
                        "currencyCode": "USD",
                        "priceAmount1000": "20000000",
                        "retailerId": "Ghost",
                        "productImageCount": 1
                    },
                    "businessOwnerJid": "0@s.whatsapp.net"
                }
            }
        }
        global.fdocs = {
            key: { participant: '0@s.whatsapp.net' },
            message: {
                documentMessage: {
                    title: me,
                    jpegThumbnail: fs.readFileSync('./image/me.png')
                }
            }
        }
        global.fgclink = {
            "key": {
                "fromMe": false,
                "participant": "0@s.whatsapp.net",
                "remoteJid": "0@s.whatsapp.net"
            },
            "message": {
                "groupInviteMessage": {
                    "groupJid": "17608914335-1625305606@g.us",
                    "inviteCode": "null",
                    "groupName": "Iyh",
                    "caption": me,
                    'jpegThumbnail': fs.readFileSync('./image/me.png')
                }
            }
        }
        global.fgif = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net", ...(m.chat ?
                    { remoteJid: "17608914335-1625305606@g.us" } : {})
            },
            message: {
                "videoMessage": {
                    "title": me,
                    "h": "Hmm",
                    'seconds': '999999999',
                    'gifPlayback': 'true',
                    'caption': me,
                    'jpegThumbnail': fs.readFileSync('./image/me.png')
                }
            }
        }
        //Fakes Random
        let fek = [global.ftroli, global.fkontak, global.fvn, global.fvid, global.ftextt, global.fliveLoc, global.fliveLoc2, global.ftoko, global.fdocs, global.fgclink, global.fgif]

        //Get Random Fake
        global.fake = pickRandom(fek)
    }
}

export default handler

function ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH')
    let res = "Selamat malam 🌙"
    if (time >= 4) {
        res = "Selamat pagi 🌄"
    }
    if (time > 10) {
        res = "Selamat siang ☀"
    }
    if (time >= 15) {
        res = "Selamat sore 🌅"
    }
    if (time >= 18) {
        res = "Selamat malam 🌙"
    }
    return res
}

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}