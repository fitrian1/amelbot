import { generateWAMessageFromContent } from '@adiwajshing/baileys'
import jimp from 'jimp'
import fetch from "node-fetch"
import canvacord from 'canvacord'
import { canLevelUp, xpRange } from '../lib/levelling.js'

let handler = async (m, { conn }) => {
  // img user
  let pic = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')
  
  // data user
  let user = global.db.data.users[m.sender]
  if (!user) throw 'Data pengguna tidak ditemukan'
  
  let users = Object.entries(global.db.data.users).map(([key, value]) => {
    return { ...value, jid: key }
  })
  
  let { min, xp, max } = xpRange(user.level, global.multiplier)
  
  // Ensure the required user data is present
  if (!user.level) user.level = 0
  if (!user.exp) user.exp = 0

  // Sorting and leveling
  let sortedLevel = users.map(toNumber('level')).sort(sort('level'))
  let usersLevel = sortedLevel.map(enumGetKey)

  // text
  const text = `*\`🌟 Selamat datang di dashboard 2bot Amel\`*!\n`
  `*\`
  > ────────────────\n         Perkenalkan Saya Adalah Bot Amel, Saya harap Anda menikmati pengalaman pertama berinteraksi dengan saya, mohon diingat saya hanyalah seorang bot bukan orang biasa yang bisa chatan seperti orang pada umumnya, saya hanya merespon terhadap command yang diberikan.\n\nSaya telah menyertakan berbagai fitur untuk membantu Anda dalam hal yang ingin dibutuhkan dalam bot.\n\n         Semoga Anda menikmati menggunakan dashboard dari saya dan mendapatkan manfaat dari fitur-fitur ya6ng saya tawarkan.\n> ────────────────\`*!\n`
  

  // Canvas
  const rank = new canvacord.Rank()
    .setRank(usersLevel.indexOf(m.sender) + 1)
    .setLevel(user.level)
    .setAvatar(pic)
    .setCurrentXP(user.exp - min)
    .setRequiredXP(xp)
    .setStatus('online')
    .setProgressBar('#FFFFFF', 'COLOR')
    .setUsername(conn.getName(m.sender))
    .setBackground('IMAGE', 'https://i.ibb.co/rxWdgSL/marin.jpg')
  
  await conn.sendFile(m.chat, await rank.build(), 'level.jpg', text, m)
}

handler.help = ['level']
handler.tags = ['xp']
handler.command = /^(lv)$/i
handler.register = true;

export default handler

function sort(property, ascending = true) {
  if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
  else return (...args) => args[ascending & 1] - args[!ascending & 1]
}

function toNumber(property, _default = 0) {
  if (property) return (a, i, b) => {
    return { ...b[i], [property]: a[property] === undefined ? _default : a[property] }
  }
  else return a => a === undefined ? _default : a
}

function enumGetKey(a) {
  return a.jid
}