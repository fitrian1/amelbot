import fetch from 'node-fetch'
let handler = async (m, { conn, command, usedPrefix }) => {
let str = `${conn.getName(m.sender)}
Want iklan Bot?

  Saya menghasilkan uang secara otomatis
 dengan GoShare melalui WhatsApp dan
 sekarang saya mengundang Anda untuk
 bergabung.
 
 Daftar sekarang dan dapatkan kesempatan 
 mendapatkan Rp 50.000 setiap harinya

https://server.go-share.top/invite/45104962`
await conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: '1000',
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
      extendedTextMessage: {
      text: str,
      contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
}
handler.help = ['iklan']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

export default handler