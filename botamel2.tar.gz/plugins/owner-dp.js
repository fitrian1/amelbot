import fs from 'fs'
let handler = async (m, {
  usedPrefix,
  command,
  text
}) => {
  try {
    if (!text) return m.reply(`Example: ${usedPrefix + command} menu`) 
    let path = `plugins/${text}.js`
    if (!fs.existsSync(path)) return m.reply(`*plugins/${text}.js* Not found`)
    fs.unlinkSync(path)
    m.reply(`"plugins/${text}.js" Removed successfully`)
  } catch (e) {
    console.log(e)
    return m.reply(Func.jsonFormat(e))
  }
}
handler.help = ['delplug']
handler.tags = ['owner']
handler.command = /^(dp|delplug|deleteplugins)$/i
handler.owner = true
export default handler