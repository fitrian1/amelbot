global.messageTemplate: "Hello @everyone, **{author}** just now uploaded a video **{title}**!\n{url}"
global.channel_id: "UC6Gnq8egewfIKibLzkr_Lng"
