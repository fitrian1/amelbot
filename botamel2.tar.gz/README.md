<p align="center">
<img src="https://wsrv.nl/?url=https://github.com/FahriAdison.png?size=500&w=300&h=300&fit=cover&mask=circle" width="75%" style="margin-left: auto;margin-right: auto;display: block;">
  
<p align="center">
<img src="https://wsrv.nl/?url=https://github.com/Johannes2803.png?size=500&w=300&h=300&fit=cover&mask=circle" width="75%" style="margin-left: auto;margin-right: auto;display: block;">
  
</p>
<h1 align="center">New-WaBot</h1>
<p align="center">
  <a href="https://github.com/FahriAdison/New-WaBot"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=We+Are+Duo+Team;Base+ori+by+BochilGaming;Recode+And+Made+By+Us;Follow+My+Github" alt="Thx">
</p>

------

#### Special Thanks to
[![Farel](https://github.com/Rlxfly.png?size=100)](https://github.com/Rlxfly)
[![Johannes](https://github.com/Johannes2803.png?size=100)](https://github.com/Johannes2803)
[![AyGemuy](https://github.com/AyGemuy.png?size=100)](https://github.com/AyGemuy)

` Yang Telah Membantu Saya Dalam Mengembangkan SC Ini`

## _「 ENGLISH 」_
> You can also recode this bot, it's easy for newbie in code/whatsapp bot, `If you have problem chat me` in [this](https://wa.me/6285767373425) or [this](https://wa.me/6282268003229) `NOTE!` if you chat to me impolitely, then I won't answer it, get used to greeting first :)

## _「 INDONESIA 」_
> Kamu juga bisa membuat ulang bot ini, ini sangat mudah untuk pemula dalam programing/bot whatsapp `Jika kamu punya masalah chat sy` ke [ini](https://wa.me/6285767373425) atau [ini](https://wa.me/6282268003229) `CATATAN!` jika kamu chat ke saya dengan tidak sopan 'p, woi', maka saya tidak akan menjawabnya, biasakan sapa/salam terlebih dahulu :)

------

---------
#### KELEBIHAN DARI SC INI 📍
| Kelebihan | Check |
|--------|--------|
| **Fast Respon** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **No Internet** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Simple** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Multi Device** |[✔️](https://github.com/FahriAdison/New-WaBot) |
---------
#### FITUR 📍
| Fitur | Check |
|--------|--------|
| **Downloader** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Internet** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Rpg** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Nsfw** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Sticker** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Game** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Kerang Ajaib** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Quotes** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Anime** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Tools** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **Fun** |[✔️](https://github.com/FahriAdison/New-WaBot) |
| **DLL** |[✔️](https://github.com/FahriAdison/New-WaBot) |
---------
[![Visitor](https://img.shields.io/github/watchers/FahriAdison/New-WaBot.svg?style=social)](https://github.com/FahriAdison/New-WaBot)
</a>
<a href="https://github.com/FahriAdison/New-WaBot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/FahriAdison/New-WaBot?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/FahriAdison/New-WaBot/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/FahriAdison/New-WaBot?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/FahriAdison/New-WaBot/graphs/contributors"><img title="Contributors" src="https://img.shields.io/github/contributors/FahriAdison/New-WaBot?label=Contributors&color=blue&style=flat-square"></a>

## UNTUK PENGGUNA REPLIT

[![Run on Repl.it](https://repl.it/badge/github/FahriAdison/New-WaBot)](https://replit.com)
```cmd
Buka Console
------------
> npm i
> npm i qrcode
> install-pkg webp
> install-pkg ffmpeg
-------------
Click Run
```
## FOR OKTETO

* Okteto [`Click Here`](https://okteto.com)

```bash
Login with your github
Click Launch Dev Environment
Choose your repo
```

## UNTUK PENGGUNA WINDOWS/VPS/RDP

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)
* Unduh & Instal ImageMagick [`Klik Disini`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/FahriAdison/New-WaBot
cd bot-md
npm i
node .
```

## UNTUK PENGGUNA TERMUX

* Download Termux [`Klik Disini`](https://github.com/termux/termux-app/releases/download/v0.118.0/termux-app_v0.118.0+github-debug_universal.apk)

```
$ pkg update && upgrade -y
$ apt update && upgrade -y
$ pkg install ffmpeg
$ pkg install nodejs-lts
$ pkg install git
$ git clone https://github.com/FahriAdison/New-WaBot
$ cd bot-md
$ npm i
$ node .
```

---------

---------

### 📮 BACA ATURAN SEBELUM MEMAKAI SC INI
1. Jangan diperjualbelikan Script ini !!
2. Follow Github Untuk Update Lebih Lanjut !!
3. Jangan salah gunakan script ini,gunakan dengan bijak!!
4. Jangan lupa Subscribe Youtube Papah-Chan
5. Jika scriptnya error', langsung hubungi kami berdua

---------

Ada Yg Error?Langsung Chat
[Disini](https://wa.me/6282268003229)
Atau
[Disini](https://wa.me/6285767373425)

NOTE: UBAH APIKEY,NAMA OWNER,NAMA BOT DI CONFIG.JS

---------

## ```Thanks to ✨```
* [`Allah SWT`](https://github.com/FahriAdison/New-WaBot)
* [`My parents`](https://github.com/FahriAdison/New-WaBot)
* [`My partner`](https://github.com/FahriAdison/New-WaBot)
* [`All My Friends`](https://github.com/FahriAdison/New-WaBot)
* [`All Contributors`](https://github.com/FahriAdison/New-WaBot)
* [`All Creator Bot`](https://github.com/FahriAdison/New-WaBot)

## ```Recode By 💌```
[![Fahri](https://wsrv.nl/?url=https://github.com/FahriAdison.png?size=100&mask=circle)](https://github.com/FahriAdison)

[![Johannes](https://wsrv.nl/?url=https://github.com/Johannes2803.png?size=100&mask=circle)](https://github.com/Johanne2803)

---------